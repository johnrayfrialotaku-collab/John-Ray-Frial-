package com.jrf.organizers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.work.*
import java.util.concurrent.TimeUnit

object Perm {
    fun granted() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
}

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var rank: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        fun pad(v: Int) = (v * dp).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundResource(R.drawable.bg_gate); setPadding(pad(24), pad(48), pad(24), pad(24))
        }
        // Optional: drop your own picture at res/drawable/hero.jpg (or .png) to replace the default emblem.
        val heroId = resources.getIdentifier("hero", "drawable", packageName)
        root.addView(ImageView(this).apply {
            setImageResource(if (heroId != 0) heroId else R.drawable.ic_shadow)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, LinearLayout.LayoutParams(pad(180), pad(180)))
        fun text(s: String, size: Float, color: Int) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD); setShadowLayer(18f, 0f, 0f, Color.parseColor("#3d8bff"))
        }
        root.addView(text("John Ray Frial\nOrganizers", 28f, Color.WHITE).apply { setPadding(0, pad(16), 0, pad(4)) })
        rank = text("", 16f, Color.parseColor("#5ec8ff")); root.addView(rank)
        status = text("Grant file access, then press ARISE.", 15f, Color.parseColor("#9fb4e8")).apply { setPadding(0, pad(20), 0, pad(20)) }
        root.addView(status)
        fun btn(s: String, bg: String, click: () -> Unit) = Button(this).apply {
            text = s; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor(bg)); setOnClickListener { click() }
        }
        root.addView(btn("1. GRANT FILE ACCESS", "#1b3fbf") { askPermission() }, LinearLayout.LayoutParams(-1, pad(56)))
        root.addView(btn("2. ARISE (ORGANIZE NOW)", "#5a2cff") { arise() }, LinearLayout.LayoutParams(-1, pad(56)).apply { topMargin = pad(12) })
        val sw = Switch(this).apply {
            text = "Auto-organize every 15 minutes"; setTextColor(Color.WHITE); setPadding(0, pad(20), 0, 0)
            isChecked = getSharedPreferences("jrf", MODE_PRIVATE).getBoolean("auto", false)
            setOnCheckedChangeListener { _, on -> setAuto(on) }
        }
        root.addView(sw)
        setContentView(root)
        refreshRank()
    }

    override fun onResume() { super.onResume(); refreshRank() }

    private fun refreshRank() {
        val xp = getSharedPreferences("jrf", MODE_PRIVATE).getInt("xp", 0)
        val lv = xp / 100 + 1
        val r = when { lv < 3 -> "E"; lv < 6 -> "D"; lv < 10 -> "C"; lv < 15 -> "B"; lv < 22 -> "A"; else -> "S" }
        rank.text = "Rank $r  |  Lv. $lv  |  ${xp % 100}/100 XP"
    }

    private fun askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Perm.granted()) toast("Access already granted.")
            else startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
    }

    private fun arise() {
        if (!Perm.granted()) { status.text = "[SYSTEM] File access is required. Tap step 1."; return }
        val n = Organizer.run(this)
        status.text = if (n > 0) "[ARISE] $n files joined your shadow army.\nFind them in Download/JRF Organized." else "[SYSTEM] No loose files found in Download or Documents."
        refreshRank()
    }

    private fun setAuto(on: Boolean) {
        getSharedPreferences("jrf", MODE_PRIVATE).edit().putBoolean("auto", on).apply()
        val wm = WorkManager.getInstance(this)
        if (on) wm.enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, PeriodicWorkRequestBuilder<AutoWorker>(15, TimeUnit.MINUTES).build())
        else wm.cancelUniqueWork("auto")
        toast(if (on) "Auto-organize enabled." else "Auto-organize disabled.")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
