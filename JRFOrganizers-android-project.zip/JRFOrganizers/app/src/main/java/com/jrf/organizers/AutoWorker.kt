package com.jrf.organizers

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class AutoWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        if (Perm.granted()) Organizer.run(applicationContext)
        return Result.success()
    }
}
