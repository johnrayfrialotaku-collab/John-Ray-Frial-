package com.jrf.organizers

import android.content.Context
import android.os.Environment
import java.io.File

object Organizer {
    private val groups = linkedMapOf(
        "Image Shadows" to "jpg jpeg png gif webp bmp heic avif svg",
        "Video Shadows" to "mp4 mkv mov avi webm 3gp flv",
        "Sound Shadows" to "mp3 wav flac aac ogg m4a opus",
        "Scroll Archive" to "pdf doc docx txt rtf odt ppt pptx xls xlsx csv epub",
        "Sealed Vaults" to "zip rar 7z tar gz",
        "Artifacts" to "apk xapk aab"
    )
    private val partial = setOf("crdownload", "part", "tmp", "download", "temp")

    /** Moves loose files from Download and Documents into Download/JRF Organized/<group>. Returns count moved. */
    fun run(ctx: Context): Int {
        val root = Environment.getExternalStorageDirectory()
        val out = File(root, "Download/JRF Organized")
        var moved = 0
        for (src in listOf(File(root, "Download"), File(root, "Documents"))) {
            src.listFiles()?.forEach { f ->
                if (!f.isFile || f.name.startsWith(".")) return@forEach
                val ext = f.extension.lowercase()
                if (ext in partial || System.currentTimeMillis() - f.lastModified() < 120_000) return@forEach
                val group = groups.entries.firstOrNull { ext in it.value.split(" ") }?.key ?: "Unknown Relics"
                val dir = File(out, group).apply { mkdirs() }
                var dest = File(dir, f.name); var n = 1
                while (dest.exists()) {
                    dest = File(dir, f.nameWithoutExtension + " (" + n + ")" + (if (ext.isEmpty()) "" else "." + ext)); n++
                }
                if (f.renameTo(dest)) moved++
            }
        }
        val p = ctx.getSharedPreferences("jrf", Context.MODE_PRIVATE)
        p.edit().putInt("xp", p.getInt("xp", 0) + moved * 10).apply()
        return moved
    }
}
