John Ray Frial Organizers - Android project
1. Install Android Studio (free) and choose File > Open > this folder. Let Gradle sync.
2. Build > Build APK(s). The APK appears in app/build/outputs/apk/debug/.
3. Copy the APK to your phone and install it (allow "install unknown apps").
4. Optional: put your own picture at app/src/main/res/drawable/hero.jpg to show it at the top.
